Build a blog with javascript and mongodb
=====

A blog made out of the javascripts. Uses mongoose, angular, express and the node.js and the mongodbs for realz


#### Getting started
```
$ git clone <this_repo>
$ npm install
$ node server 
```

**Tutorial part 1:** https://connorleech.ghost.io/build-a-blog-with-the-mean-stack-part-1/
