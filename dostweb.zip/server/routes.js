var express = require('express'),
	path = require('path'),
	User = require('./models/user'),
	rootPath = path.normalize(__dirname + '/../'),
	apiRouter = express.Router(),
	router = express.Router();
// Send Emails using nodemailer & email templates
        nodemailer = require('nodemailer'),
      //  EmailTemplate = require('email-templates').EmailTemplate,
      //  Upload File (for .csv)
//       fileUpload = require('express-fileupload'),
        // image upload
        aws = require('aws-sdk'),
        multer = require('multer'),
        multerS3 = require('multer-s3'),
        dateNow = Date.now();

// mail 
var transporter = nodemailer.createTransport({
    host: 'email-smtp.us-east-1.amazonaws.com',
    port: 465,
    auth: {
        user: "AKIAIYPER6NYT2NLRSXQ",
        pass: "AnkZVDEhd4F96AyqyXI5xJENd6j6wgGSDb52mVN9jf0B"
    }
});

aws.config.update({
    secretAccessKey: 'kBWbO7oEt3T/+OBGNvVrIY0fkkoq7O6ZqLYCFZdC',
    accessKeyId: 'AKIAJEVW6QRFPIM4PQCQ'
});
var s3 = new aws.S3({
    endpoint: 'https://s3.eu-central-1.amazonaws.com',
    region: 'us-east-1',
    signatureVersion: 'v4',
    ACL: 'public-read',
    //   Bucket: 'dostbucket'
});
var vendortypeupload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'dostbucket',
        key: function (req, file, cb) {
            var flname = file.originalname;
            cb(null, 'vendortypes/' + dateNow + '' + flname); //use Date.now() for unique file keys
        }
    })
});
var serviceupload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'dostbucket',
        key: function (req, file, cb) {
            var flname = file.originalname;
            cb(null, 'services/' + dateNow + '' + flname); //use Date.now() for unique file keys
        }
    })
});
var userupload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'dostbucket',
        key: function (req, file, cb) {
            var flname = file.originalname;
            cb(null, 'users/' + dateNow + '' + flname); //use Date.now() for unique file keys
        }
    })
});
var eventsupload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'dostbucket',
        key: function (req, file, cb) {
            var flname = file.originalname;
            cb(null, 'events/' + dateNow + '' + flname); //use Date.now() for unique file keys
        }
    })
});
var invoicesupload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'dostbucket',
        key: function (req, file, cb) {
            var flname = file.originalname;
            cb(null, 'invoices/' + dateNow + '' + flname); //use Date.now() for unique file keys
        }
    })
});

module.exports = function(app, passport){	
	app.use('/api', apiRouter);
	app.use('/', router);

	// API routes
	require('./api/jobposts')(apiRouter);
        require('./api/users')(apiRouter,passport,userupload,transporter);
        require('./api/vendortypes')(apiRouter,vendortypeupload);
        require('./api/services')(apiRouter,serviceupload);
        require('./api/highlights')(apiRouter);
        require('./api/business')(apiRouter);
        require('./api/cities')(apiRouter);
        require('./api/events')(apiRouter,eventsupload);
        require('./api/milestones')(apiRouter);
        require('./api/projects')(apiRouter,transporter);
        require('./api/tasks')(apiRouter);
        require('./api/fields')(apiRouter);
        require('./api/groups')(apiRouter);
        require('./api/guests')(apiRouter,transporter);
        require('./api/invitations')(apiRouter,transporter);
        require('./api/livejobs')(apiRouter);
        require('./api/proposals')(apiRouter);
        require('./api/clients')(apiRouter,transporter);
        require('./api/budgets')(apiRouter,invoicesupload);
        require('./api/hotels')(apiRouter);
        require('./api/foodRestrictions')(apiRouter);
        require('./api/messages')(apiRouter);
        require('./api/favourites')(apiRouter);
        require('./api/jobmilestones')(apiRouter);
        require('./api/payments')(apiRouter);
        
//        app.use('/scripts', express.static(__dirname + '/node_modules/'));

        
	// home route
	router.get('/',function(req, res) {
            if(req.user){
                res.render('frontend/dashboard', {user: req.user});
            }else{
                res.render('frontend/login');
            }
	});
        //Is LoggedIn user
        router.get('/dost',function(req, res) {
            if(req.isAuthenticated()){
                res.render('frontend/dashboard', {user: req.user});
            }else{
               // console.log('not logged in')
                res.render('frontend/dashboard', {user: ''});
            }
            
	});
        router.post('/dostlogin', passport.authenticate('local', { failureRedirect: '/?err' }),function(req, res){
            res.redirect('/dost');
	});
//        router.post('/dostlogin', passport.authenticate('local'),function(req, res){
//            console.log(res)
//            res.redirect('/dost');
//	});

	// admin route
	router.get('/admin', function(req, res) {
		res.render('admin/login');
	});

	router.get('/admin/register', function(req, res) {
		res.render('admin/register');
	});

	router.get('/admin/dashboard', isAdmin, function(req, res){
		res.render('admin/dashboard', {user: req.user});
	});

	router.post('/register', function(req, res){

		// passport-local-mongoose: Convenience method to register a new user instance with a given password. Checks if username is unique
		User.register(new User({
			phone: req.body.phone
		}), req.body.password, function(err, user) {
	        if (err) {
//	            console.error(err);
	            return;
	        }

	        // log the user in after it is created
	        passport.authenticate('local')(req, res, function(){
//	        	console.log('authenticated by passport');
	        	res.redirect('/admin/dashboard');
	        });
	    });
	});

	router.post('/login', passport.authenticate('local'), function(req, res){
            res.redirect('/admin/dashboard');
	});
        // Logout from website
        router.get('/logout', function (req, res) {
            req.logout();
            res.redirect('/');
        });
        // Logout from admin
        router.get('/admin/logout', function (req, res) {
            req.logout();
            res.redirect('/');
        });

	app.use(function(req, res, next){
		res.status(404);

		res.render('404');
		return;
	});
	
};

function isAdmin(req, res, next){
	if(req.isAuthenticated() && req.user.phone === '+919876859015'){
		//console.log('cool you are an admin, carry on your way');
		next();
	} else {
		//console.log('You are not an admin');
		res.redirect('/admin');
	}
}
// user is logged in or not
function isLoggedIn(req, res, next){
	if(req.isAuthenticated()){
		//console.log('cool you are an loggedin, carry on your way');
		next();
	} else {
		//console.log('You are not an admin url');
                res.redirect('/dost')
		//res.redirect('/');
	}
}